import time
import random
import threading as th
import Queue
import numpy as np
import bluetooth
import socket
import scipy.fftpack
from MindwaveDataPoints import RawDataPoint, BlinkDataPoint, MeditationDataPoint, AttentionDataPoint
from MindwaveDataPointReader import MindwaveDataPointReader


if __name__ == '__main__':
    
    mindwaveDataPointReader = MindwaveDataPointReader()
    mindwaveDataPointReader.start()
    
    
    while(1):
		
        
        dataPoint = mindwaveDataPointReader.readNextDataPoint()
        
        if (dataPoint.__class__ is BlinkDataPoint):
			print dataPoint

  
  	
	
		
		
	
