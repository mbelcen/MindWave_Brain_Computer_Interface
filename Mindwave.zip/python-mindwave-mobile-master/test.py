import time
import random
import threading as th
import Queue
import numpy as np
import bluetooth
import socket
import scipy.fftpack
from MindwaveDataPoints import RawDataPoint, BlinkDataPoint
from MindwaveDataPointReader import MindwaveDataPointReader


def get_data(q1,q2):
    
    mindwaveDataPointReader = MindwaveDataPointReader()
    mindwaveDataPointReader.start()
    
    raw_data=[]
    blink_data=[]
    
    while(1):
		
        
        dataPoint = mindwaveDataPointReader.readNextDataPoint()
        
        if (dataPoint.__class__ is RawDataPoint):
			raw_data.append(dataPoint)
			q1.put(raw_data)
			
        elif (dataPoint.__class__ is BlinkDataPoint):
			blink_data.append(dataPoint)
			q2.put(blink_data)
        else:
			pass	


  
  	
	
		
		
	
def get_ratio(q1,q2):
	
	
	
	
    M = [[],[],[],[],[],[],[],[]]
    fft_avg = []
    fft_avg_mod = []
    j=0
    k=0
    while(1):
		
		
		if k > 7 :
			fft_avg[:] = []
			fft_avg_mod[:] = []
			fft_avg = [(l1+l2+l3+l4+l5+l6+l7+l8)/8 for l1,l2,l3,l4,l5,l6,l7,l8 in zip(M[0],M[1],M[2],M[3],M[4],M[5],M[6],M[7])]
			fft_avg_mod = [ abs(x) for x in fft_avg]
			
		if fft_avg_mod:
			d=random.randint(8,14)
			e=random.randint(14,20)
			alpha=fft_avg_mod[d]
			beta=fft_avg_mod[e]
			ratio=beta/alpha
			print 'ratio' , ratio
			
		
		#raw data
		time.sleep(0.1)
		raw_data = q1.get()
		f=k%8
		M[f] = np.fft.fft(raw_data[j:j+32])
		j = j + 32	
		k = k + 1
		#blink data
		blink_data = q2.get()
		print 'blink', blink_data[k]


if __name__ == '__main__':
	
	q1 = Queue.Queue(maxsize=0)
	q2 = Queue.Queue(maxsize=0)
	try:
	   threadLock = th.Lock()
	   threads=[]
	   thread1=th.Thread( target=get_data, args=(q1,q2,))
	   thread2=th.Thread( target=get_ratio, args=(q1,q2,))
	   thread1.start()
	   print 'T1 started'
	   time.sleep(10)
	   thread2.start()
	   print 'T2 started'
	   threads.append(thread1)
	   threads.append(thread2)
	   for t in threads:
			t.join()
	except:
	   print "Error: unable to start thread"
